module.exports = {
  publicPath: "./",
  outputDir: "docs",
	productionSourceMap: false,
	devServer: {
		port: 5000
	}
};