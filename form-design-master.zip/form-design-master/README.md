# 动态表单页面设计

### 提示
预览功能需启动 form-design-h5 项目

See [form-design-h5](https://github.com/vincentzyc/form-design-h5).

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```