<template>
  <div class="flex flex-center" style="height:100%">
    <img :src="BASE_URL+'static/img/404.jpg'" alt>
  </div>
</template>

<script>
export default {};
</script>